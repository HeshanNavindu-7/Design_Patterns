﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design_pattens
{
    public class Usplug_Adaptee
    {
        public void connect()
        {
            Console.WriteLine("Usplug connected");
        }
    }
}
